#include "stm32f10x.h"                  // Device header
#include "Delay.h" 
#include  "LED.h"
#include "Key.h"
#include "usart.h"
#include "dht11.h"
#include "adc.h"
#include "vl53l0.h"
#include "sys.h"
#include "beep.h"




//////////////////////////////////////////////////////////////////////////
//ѹ����������ض���
#define PRESS_MIN	20
#define PRESS_MAX	6000 //ѹ��������������20-60
#define VOLTAGE_MIN 100
#define VOLTAGE_MAX 3300

u8 state = 0;
u16 val = 0;
u16 value_AD = 0;

long PRESS_AO = 0;
int VOLTAGE_AO = 0;

long map(long x, long in_min, long in_max, long out_min, long out_max);
////////////////////////////////////////////////////////////////////////////
//�����ഫ����

extern VL53L0X_Error vl53l0x_status;
extern VL53L0X_RangingMeasurementData_t vl53l0x_data;
extern VL53L0X_Dev_t vl53l0x_dev;

void bsp_init(void)
{	  	  
	NVIC_Configuration(); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ� 
	 
    vl53l0x_init();     
   
}


/*************
���߷���
SCL     ---   PA3
SDA     ---   PA2
VCC     ---   3.3V
GND     ---   GND
GPIO1   ---   ����
XSHUT   ---   ����
**************/
/////////////////////////////////////////////////////////////////////////////
uint8_t KeyNum;


//typedef struct
//{
//	u8 heada;
//	u8 taila;
//	u8 direction_01;	
//	u8 data[5];
//}send_stack_InitTypeDef;

//send_stack_InitTypeDef tx_stack;

//void tx_stack_init()
//{
//	tx_stack.heada = 0xaa;        //֡ͷ
//	tx_stack.direction_01= 0xbb;    	
//	memset(tx_stack.data,0,sizeof(tx_stack.data));
//	tx_stack.taila = 0xdd;        //֡β
//	
//}

//void usart_senddata()
//{
//	u8 i;
//	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
//	USART_SendData(USART1,tx_stack.heada);
//	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
//	USART_SendData(USART1,tx_stack.direction_01);
//	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
//	for(i=0;i<5;i++)
//	{
//		USART_SendData(USART1,tx_stack.data[i]);
//		while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
//	}
//	USART_SendData(USART1,tx_stack.taila);
//	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
//	Delay_ms(200);
//}

int	main(void)
{
	LED_Init();
	Key_Init();
	usart_config();
//	u8 len = 5;
//	tx_stack_init();
    Adc_Init();
	BEEP_Init();	
	char USART1_ReceiveData = 0; //rcecive PC data
	USART_ClearFlag(USART1,USART_FLAG_RXNE);//����ǰ����ձ�־λ
	
	

	
	
///////////////////////////�����ഫ����////////////////////////////////
	bsp_init();
/////////////////////////////////////////////////////////////////////////////////
	
	
	
	while(1)
	{	

		LED1_Turn();
		u8 buffer[5];		
        double hum;
        double temp;	
		
		
/////////////////////�¶ȴ�����///////////////////////////////		
		if (dht11_read_data(buffer) == 0)
        {
            hum = buffer[0] + buffer[1] / 10.0;
            temp = buffer[2] + buffer[3] / 10.0;
//			hum = buffer[0];
//          temp = buffer[2];
//			for(int i=0;i<5;i++)
//			{
//				tx_stack.data[i]=buffer[i];
//			}		
				}
///////////////////////ѹ��������////////////////////////////////////
		value_AD = Get_Adc_Average(1,10);	//10��ƽ��ֵ
		VOLTAGE_AO = map(value_AD, 0, 4095, 0, 3300);
		if(VOLTAGE_AO < VOLTAGE_MIN)
		{
			PRESS_AO = 0;
		}
		else if(VOLTAGE_AO > VOLTAGE_MAX)
		{
			PRESS_AO = PRESS_MAX;
		}
		else
		{
			PRESS_AO = map(VOLTAGE_AO, VOLTAGE_MIN, VOLTAGE_MAX, PRESS_MIN, PRESS_MAX);
		}					
////////////////////////////////////////////////////////////
//		usart_senddata();
//		usart_printf("ADֵ = %d,��ѹ = %d mv,ѹ�� = %ld g\r\n",value_AD,VOLTAGE_AO,PRESS_AO);	
//		usart_printf("___{\"��ǰ�¶�\": %.2f, \"��ǰʪ��\": %.2f}___\n", temp, hum);		
//		usart_printf("��ǰ�¶�: %.2f , ��ǰʪ��: %.2f \r\n", temp, hum);
/////////////////////////�����ഫ�����������////////////////////////////////		
      if(vl53l0x_status == VL53L0X_ERROR_NONE)
		  {
          vl53l0x_start_single_test(&vl53l0x_dev, &vl53l0x_data); //�������Ϊmm
          }
/////////////////////////ѹ�����¶ȡ�ʪ���������////////////////////////////////		  
		usart_printf("%d,%.2f,%.2f",PRESS_AO,temp,hum);
////////////////////////���ط�������Ӧ/////////////////////////////////////////
		if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==1)
		{
			USART1_ReceiveData = USART_ReceiveData(USART1);
			USART_ClearFlag(USART1,USART_FLAG_RXNE); //���պ�������ձ�־λ
		}
		if('1' == USART1_ReceiveData)
		{
			BEEP_ON();
		}
		if('2' == USART1_ReceiveData)
		{
			BEEP_OFF();
		}
		if('3' == USART1_ReceiveData)
		{
			play_music_hcqg();
		}
		USART1_ReceiveData = 0;
		Delay_ms(200);

	} 

}

long map(long x, long in_min, long in_max, long out_min, long out_max) 
	{
 return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

